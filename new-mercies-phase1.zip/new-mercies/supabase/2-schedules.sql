-- =====================================================================
-- NEW MERCIES — scheduled jobs
-- Run AFTER 1-schema.sql and AFTER both Edge Functions are deployed.
-- SQL Editor → New query → paste → Run. Safe to run again: it replaces
-- any earlier versions of these jobs.
--
-- Times are locked to Eastern local time all year:
--   9 AM Eastern  — moderators alerted about anyone who missed two days
--   7 PM Eastern  — reminder to anyone who hasn't checked in today
-- Each job fires at both possible UTC hours (standard and daylight time);
-- the server function only acts on the one that matches Eastern time.
-- =====================================================================

create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Remove earlier versions of these jobs, if any
select cron.unschedule(jobname) from cron.job
where jobname in ('nm-missed-checkins', 'nm-daily-reminder', 'nm-share-cleanup');

-- 9 AM Eastern = 13:00 UTC (daylight time) or 14:00 UTC (standard time)
select cron.schedule('nm-missed-checkins', '0 13,14 * * *', $job$
  select net.http_post(
    url     := 'https://uxozxcbnlljxktkvsprd.supabase.co/functions/v1/notify',
    headers := jsonb_build_object('Content-Type', 'application/json',
               'x-cron-secret', (select value from public.app_secrets where key = 'cron_secret')),
    body    := '{"action":"missed","at_hour":9}'::jsonb
  );
$job$);

-- 7 PM Eastern = 23:00 UTC (daylight time) or 00:00 UTC (standard time)
select cron.schedule('nm-daily-reminder', '0 23,0 * * *', $job$
  select net.http_post(
    url     := 'https://uxozxcbnlljxktkvsprd.supabase.co/functions/v1/notify',
    headers := jsonb_build_object('Content-Type', 'application/json',
               'x-cron-secret', (select value from public.app_secrets where key = 'cron_secret')),
    body    := '{"action":"remind","at_hour":19}'::jsonb
  );
$job$);

-- Nightly: shares disappear after 90 days
select cron.schedule('nm-share-cleanup', '0 8 * * *', $job$
  delete from public.shares where created_at < now() - interval '90 days';
$job$);

select jobname, schedule from cron.job order by jobname;
