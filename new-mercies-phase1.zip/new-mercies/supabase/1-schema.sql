-- =====================================================================
-- NEW MERCIES — database setup (Phase 1)
-- Run this ONCE in Supabase: SQL Editor → New query → paste → Run.
-- The last result shows your first moderator invite code.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------- Core tables ----------------------------------------------

create table public.clusters (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);
insert into public.clusters (name) values ('Main group');

create table public.members (
  id uuid primary key references auth.users(id) on delete cascade,
  handle text not null check (char_length(handle) between 2 and 24),
  role text not null default 'member' check (role in ('member','moderator')),
  cluster_id uuid not null references public.clusters(id),
  start_date date not null,
  current_step int not null default 1 check (current_step between 1 and 12),
  must_change_password boolean not null default false,
  joined_at timestamptz not null default now()
);
create unique index members_handle_unique on public.members (lower(handle));

-- Today's date in the group's time zone
create or replace function public.nm_today() returns date
language sql stable as $$ select (now() at time zone 'America/New_York')::date $$;

create or replace function public.my_cluster() returns uuid
language sql stable security definer set search_path = public as $$
  select cluster_id from members where id = auth.uid()
$$;

create or replace function public.is_moderator() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from members where id = auth.uid() and role = 'moderator')
$$;

create table public.invite_codes (
  code text primary key,
  role text not null default 'member' check (role in ('member','moderator')),
  cluster_id uuid not null references public.clusters(id),
  max_uses int not null default 1 check (max_uses between 1 and 50),
  uses int not null default 0,
  expires_at timestamptz not null default now() + interval '7 days',
  created_by uuid references public.members(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.checkins (
  id bigint generated always as identity primary key,
  member_id uuid not null references public.members(id) on delete cascade,
  cluster_id uuid not null references public.clusters(id),
  day date not null,
  status text not null check (status in ('good','tempted','backslid')),
  note text check (note is null or char_length(note) <= 280),
  created_at timestamptz not null default now(),
  unique (member_id, day)
);

create table public.shares (
  id bigint generated always as identity primary key,
  member_id uuid not null default auth.uid() references public.members(id) on delete cascade,
  cluster_id uuid not null default public.my_cluster() references public.clusters(id),
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table public.share_reactions (
  share_id bigint not null references public.shares(id) on delete cascade,
  member_id uuid not null default auth.uid() references public.members(id) on delete cascade,
  kind text not null check (kind in ('congrats','encourage','laugh','metoo','praying')),
  created_at timestamptz not null default now(),
  primary key (share_id, member_id, kind)
);

create table public.prayer_requests (
  id bigint generated always as identity primary key,
  member_id uuid not null default auth.uid() references public.members(id) on delete cascade,
  cluster_id uuid not null default public.my_cluster() references public.clusters(id),
  body text not null check (char_length(body) between 1 and 1000),
  answered boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.prayer_acks (
  request_id bigint not null references public.prayer_requests(id) on delete cascade,
  member_id uuid not null default auth.uid() references public.members(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (request_id, member_id)
);

create table public.sos_events (
  id bigint generated always as identity primary key,
  member_id uuid not null references public.members(id) on delete cascade,
  cluster_id uuid not null references public.clusters(id),
  message text check (message is null or char_length(message) <= 140),
  created_at timestamptz not null default now()
);

create table public.blue_chips (
  id bigint generated always as identity primary key,
  member_id uuid not null references public.members(id) on delete cascade,
  taken_on date not null,
  previous_start date
);

create table public.push_subscriptions (
  endpoint text primary key,
  member_id uuid not null references public.members(id) on delete cascade,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);

-- Server-only tables (no client access at all)
create table public.missed_alerts (
  member_id uuid not null references public.members(id) on delete cascade,
  last_day date not null,
  alerted_at timestamptz not null default now(),
  primary key (member_id, last_day)
);
create table public.app_secrets (
  key text primary key,
  value text not null
);
insert into public.app_secrets (key, value)
values ('cron_secret', encode(extensions.gen_random_bytes(24), 'hex'));

-- ---------- Row-level security ---------------------------------------

alter table public.clusters           enable row level security;
alter table public.members            enable row level security;
alter table public.invite_codes       enable row level security;
alter table public.checkins           enable row level security;
alter table public.shares             enable row level security;
alter table public.share_reactions    enable row level security;
alter table public.prayer_requests    enable row level security;
alter table public.prayer_acks        enable row level security;
alter table public.sos_events         enable row level security;
alter table public.blue_chips         enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.missed_alerts      enable row level security;
alter table public.app_secrets        enable row level security;

create policy "see my cluster" on public.clusters for select to authenticated
  using (id = public.my_cluster());

create policy "see my group" on public.members for select to authenticated
  using (cluster_id = public.my_cluster());

create policy "moderators see invites" on public.invite_codes for select to authenticated
  using (public.is_moderator() and cluster_id = public.my_cluster());
create policy "moderators delete invites" on public.invite_codes for delete to authenticated
  using (public.is_moderator() and cluster_id = public.my_cluster());

create policy "see group check-ins" on public.checkins for select to authenticated
  using (cluster_id = public.my_cluster());

create policy "see group shares" on public.shares for select to authenticated
  using (cluster_id = public.my_cluster());
create policy "post own share" on public.shares for insert to authenticated
  with check (member_id = auth.uid() and cluster_id = public.my_cluster());
create policy "delete own share or moderate" on public.shares for delete to authenticated
  using (member_id = auth.uid() or (public.is_moderator() and cluster_id = public.my_cluster()));

create policy "see reactions" on public.share_reactions for select to authenticated
  using (exists (select 1 from public.shares s where s.id = share_id and s.cluster_id = public.my_cluster()));
create policy "add own reaction" on public.share_reactions for insert to authenticated
  with check (member_id = auth.uid() and exists (select 1 from public.shares s where s.id = share_id and s.cluster_id = public.my_cluster()));
create policy "remove own reaction" on public.share_reactions for delete to authenticated
  using (member_id = auth.uid());

create policy "see group prayers" on public.prayer_requests for select to authenticated
  using (cluster_id = public.my_cluster());
create policy "post own prayer" on public.prayer_requests for insert to authenticated
  with check (member_id = auth.uid() and cluster_id = public.my_cluster());
create policy "update own prayer" on public.prayer_requests for update to authenticated
  using (member_id = auth.uid()) with check (member_id = auth.uid());
create policy "delete own prayer or moderate" on public.prayer_requests for delete to authenticated
  using (member_id = auth.uid() or (public.is_moderator() and cluster_id = public.my_cluster()));

create policy "see prayer acks" on public.prayer_acks for select to authenticated
  using (exists (select 1 from public.prayer_requests p where p.id = request_id and p.cluster_id = public.my_cluster()));
create policy "add own ack" on public.prayer_acks for insert to authenticated
  with check (member_id = auth.uid() and exists (select 1 from public.prayer_requests p where p.id = request_id and p.cluster_id = public.my_cluster()));
create policy "remove own ack" on public.prayer_acks for delete to authenticated
  using (member_id = auth.uid());

create policy "see group sos" on public.sos_events for select to authenticated
  using (cluster_id = public.my_cluster());

create policy "see own or moderate blue chips" on public.blue_chips for select to authenticated
  using (member_id = auth.uid() or (public.is_moderator() and exists (
    select 1 from public.members m where m.id = member_id and m.cluster_id = public.my_cluster())));

create policy "see own push subs" on public.push_subscriptions for select to authenticated
  using (member_id = auth.uid());
-- missed_alerts and app_secrets: no policies = no client access.

-- ---------- Actions the app calls ------------------------------------

create or replace function public.check_in(p_status text, p_note text default null)
returns public.checkins
language plpgsql security definer set search_path = public as $$
declare r checkins; c uuid := my_cluster();
begin
  if c is null then raise exception 'Not a member'; end if;
  if p_status not in ('good','tempted','backslid') then raise exception 'Invalid status'; end if;
  insert into checkins (member_id, cluster_id, day, status, note)
  values (auth.uid(), c, nm_today(), p_status, nullif(trim(p_note), ''))
  on conflict (member_id, day) do update
    set status = excluded.status, note = excluded.note, created_at = now()
  returning * into r;
  return r;
end $$;

create or replace function public.set_step(p_step int) returns void
language sql security definer set search_path = public as $$
  update members set current_step = p_step where id = auth.uid() and p_step between 1 and 12
$$;

create or replace function public.take_blue_chip() returns date
language plpgsql security definer set search_path = public as $$
declare prev date;
begin
  select start_date into prev from members where id = auth.uid();
  if prev is null then raise exception 'Not a member'; end if;
  insert into blue_chips (member_id, taken_on, previous_start) values (auth.uid(), nm_today(), prev);
  update members set start_date = nm_today() where id = auth.uid();
  return nm_today();
end $$;

create or replace function public.clear_must_change() returns void
language sql security definer set search_path = public as $$
  update members set must_change_password = false where id = auth.uid()
$$;

create or replace function public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if my_cluster() is null then raise exception 'Not a member'; end if;
  insert into push_subscriptions (endpoint, member_id, p256dh, auth)
  values (p_endpoint, auth.uid(), p_p256dh, p_auth)
  on conflict (endpoint) do update
    set member_id = auth.uid(), p256dh = excluded.p256dh, auth = excluded.auth, created_at = now();
end $$;

create or replace function public.remove_push_subscription(p_endpoint text) returns void
language sql security definer set search_path = public as $$
  delete from push_subscriptions where endpoint = p_endpoint and member_id = auth.uid()
$$;

-- Most recent check-in day for everyone in my group
create or replace function public.group_last_checkins()
returns table (o_member_id uuid, o_last_day date)
language sql stable security definer set search_path = public as $$
  select m.id, max(c.day) from members m
  left join checkins c on c.member_id = m.id
  where m.cluster_id = my_cluster()
  group by m.id
$$;

-- Moderator actions
create or replace function public.create_invite(p_max_uses int default 1, p_days int default 7, p_role text default 'member')
returns text language plpgsql security definer set search_path = public as $$
declare new_code text;
begin
  if not is_moderator() then raise exception 'Moderators only'; end if;
  if p_role not in ('member','moderator') then raise exception 'Invalid role'; end if;
  new_code := 'NM-' || upper(substr(encode(extensions.gen_random_bytes(4), 'hex'), 1, 6));
  insert into invite_codes (code, role, cluster_id, max_uses, expires_at, created_by)
  values (new_code, p_role, my_cluster(), greatest(1, least(p_max_uses, 50)),
          now() + make_interval(days => greatest(1, least(p_days, 30))), auth.uid());
  return new_code;
end $$;

create or replace function public.set_role(p_member uuid, p_role text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_moderator() then raise exception 'Moderators only'; end if;
  if p_role not in ('member','moderator') then raise exception 'Invalid role'; end if;
  if not exists (select 1 from members where id = p_member and cluster_id = my_cluster()) then
    raise exception 'Member not found'; end if;
  if p_role = 'member' and (select count(*) from members where cluster_id = my_cluster() and role = 'moderator' and id <> p_member) = 0 then
    raise exception 'The group needs at least one moderator'; end if;
  update members set role = p_role where id = p_member;
end $$;

create or replace function public.mod_set_start(p_member uuid, p_date date) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_moderator() then raise exception 'Moderators only'; end if;
  if p_date > nm_today() then raise exception 'Date cannot be in the future'; end if;
  update members set start_date = p_date where id = p_member and cluster_id = my_cluster();
end $$;

-- ---------- Server-only helpers (used by scheduled jobs) -------------

-- Members who have missed yesterday AND the day before, not yet alerted
create or replace function public.nm_collect_missed()
returns table (o_member_id uuid, o_cluster_id uuid)
language sql security definer set search_path = public as $$
  with status as (
    select m.id, m.cluster_id,
           coalesce((select max(c.day) from checkins c where c.member_id = m.id),
                    (m.joined_at at time zone 'America/New_York')::date - 1) as last_day
    from members m
  ), due as (
    select * from status where last_day <= nm_today() - 3
  ), ins as (
    insert into missed_alerts (member_id, last_day)
    select id, last_day from due
    on conflict do nothing
    returning missed_alerts.member_id
  )
  select d.id, d.cluster_id from due d join ins on ins.member_id = d.id
$$;

create or replace function public.nm_unchecked_today()
returns table (o_member_id uuid)
language sql security definer set search_path = public as $$
  select m.id from members m
  where not exists (select 1 from checkins c where c.member_id = m.id and c.day = nm_today())
$$;

revoke execute on function public.nm_collect_missed()  from public, anon, authenticated;
revoke execute on function public.nm_unchecked_today() from public, anon, authenticated;

-- ---------- First moderator invite -----------------------------------

insert into public.invite_codes (code, role, cluster_id, max_uses, expires_at)
select 'NM-LEAD-' || upper(substr(encode(extensions.gen_random_bytes(3), 'hex'), 1, 4)),
       'moderator', id, 1, now() + interval '14 days'
from public.clusters limit 1;

select code as "YOUR FIRST MODERATOR INVITE CODE (single use)" from public.invite_codes;
