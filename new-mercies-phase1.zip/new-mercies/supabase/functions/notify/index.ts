// NEW MERCIES — "notify" Edge Function
// Handles: push setup key, SOS alerts, missed check-in alerts to moderators, daily reminders.
// Deploy in Supabase: Edge Functions → Deploy a new function → Via editor → name it "notify".
// Then in the function's settings, turn OFF "Verify JWT" (this code checks sign-in itself).
//
// Notification text is deliberately neutral, because it shows on lock screens.

import { createClient } from "npm:@supabase/supabase-js@2.49.4";
import webpush from "npm:web-push@3.6.7";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SB_SECRET_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const APP_URL = "https://rrc013.github.io/new-mercies/";
const admin = createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function secret(key: string) {
  const { data } = await admin.from("app_secrets").select("value").eq("key", key).maybeSingle();
  return data?.value as string | undefined;
}

// Push keys are created on first use and kept server-side only
let vapidReady: string | null = null;
async function vapid() {
  if (vapidReady) return vapidReady;
  let pub = await secret("vapid_public");
  let priv = await secret("vapid_private");
  if (!pub || !priv) {
    const k = webpush.generateVAPIDKeys();
    await admin.from("app_secrets").upsert(
      [{ key: "vapid_public", value: k.publicKey }, { key: "vapid_private", value: k.privateKey }],
      { onConflict: "key", ignoreDuplicates: true },
    );
    pub = await secret("vapid_public");
    priv = await secret("vapid_private");
  }
  webpush.setVapidDetails(APP_URL, pub!, priv!);
  vapidReady = pub!;
  return pub!;
}

async function caller(req: Request) {
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data.user) return null;
  const { data: m } = await admin.from("members").select("*").eq("id", data.user.id).maybeSingle();
  return m;
}

async function pushTo(memberIds: string[], payload: Record<string, string>) {
  if (!memberIds.length) return 0;
  await vapid();
  const { data: subs } = await admin.from("push_subscriptions").select("*").in("member_id", memberIds);
  let sent = 0;
  await Promise.all((subs ?? []).map(async (s) => {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
        { TTL: 6 * 3600 },
      );
      sent++;
    } catch (e) {
      const code = (e as { statusCode?: number }).statusCode;
      if (code === 404 || code === 410) {
        await admin.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
      } else console.error("push failed", code);
    }
  }));
  return sent;
}

// Current hour in Eastern time (handles daylight saving automatically)
function easternHour() {
  return Number(new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "numeric", hourCycle: "h23" }).format(new Date()));
}
// Scheduled jobs fire at both possible UTC hours; only the one matching local time does anything
function wrongHour(body: Record<string, unknown>) {
  const want = Number(body.at_hour);
  return Number.isFinite(want) && easternHour() !== want;
}

async function isCron(req: Request) {
  const given = req.headers.get("x-cron-secret");
  return !!given && given === (await secret("cron_secret"));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return json({ error: "Bad request" }, 400); }

  try {
    switch (body.action) {
      case "vapid": {
        const me = await caller(req);
        if (!me) return json({ error: "Sign in first." }, 401);
        return json({ publicKey: await vapid() });
      }

      case "test": {
        const me = await caller(req);
        if (!me) return json({ error: "Sign in first." }, 401);
        const sent = await pushTo([me.id], { title: "New Mercies", body: "Notifications are working.", url: APP_URL });
        return json({ ok: true, sent });
      }

      case "sos": {
        const me = await caller(req);
        if (!me) return json({ error: "Sign in first." }, 401);
        const since = new Date(Date.now() - 10 * 60 * 1000).toISOString();
        const { count } = await admin.from("sos_events").select("id", { count: "exact", head: true })
          .eq("member_id", me.id).gte("created_at", since);
        if ((count ?? 0) > 0) return json({ error: "Your SOS already went out a few minutes ago. The group has been notified." }, 429);

        const message = String(body.message ?? "").trim().slice(0, 140) || null;
        await admin.from("sos_events").insert({ member_id: me.id, cluster_id: me.cluster_id, message });
        const { data: others } = await admin.from("members").select("id")
          .eq("cluster_id", me.cluster_id).neq("id", me.id);
        const sent = await pushTo((others ?? []).map((o) => o.id), {
          title: "New Mercies",
          body: "A brother is asking for support right now.",
          url: APP_URL + "#group",
        });
        return json({ ok: true, sent });
      }

      case "missed": {
        if (!(await isCron(req))) return json({ error: "Forbidden" }, 403);
        if (wrongHour(body)) return json({ ok: true, skipped: "not the scheduled local hour" });
        const { data: rows, error } = await admin.rpc("nm_collect_missed");
        if (error) throw error;
        const byCluster = new Map<string, number>();
        for (const r of rows ?? []) byCluster.set(r.o_cluster_id, (byCluster.get(r.o_cluster_id) ?? 0) + 1);
        let sent = 0;
        for (const [cluster, n] of byCluster) {
          const { data: mods } = await admin.from("members").select("id")
            .eq("cluster_id", cluster).eq("role", "moderator");
          sent += await pushTo((mods ?? []).map((m) => m.id), {
            title: "New Mercies",
            body: n === 1 ? "A member has missed two check-ins." : `${n} members have missed two check-ins.`,
            url: APP_URL + "#group",
          });
        }
        return json({ ok: true, alerts: rows?.length ?? 0, sent });
      }

      case "remind": {
        if (!(await isCron(req))) return json({ error: "Forbidden" }, 403);
        if (wrongHour(body)) return json({ ok: true, skipped: "not the scheduled local hour" });
        const { data: rows, error } = await admin.rpc("nm_unchecked_today");
        if (error) throw error;
        const sent = await pushTo((rows ?? []).map((r: { o_member_id: string }) => r.o_member_id), {
          title: "New Mercies",
          body: "Time for today's check-in.",
          url: APP_URL,
        });
        return json({ ok: true, sent });
      }

      default:
        return json({ error: "Unknown action" }, 400);
    }
  } catch (e) {
    console.error(e);
    return json({ error: "Something went wrong." }, 500);
  }
});
