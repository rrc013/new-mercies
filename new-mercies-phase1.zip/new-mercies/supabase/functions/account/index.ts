// NEW MERCIES — "account" Edge Function
// Handles: sign-up with an invite code, moderator password reset, moderator remove member.
// Deploy in Supabase: Edge Functions → Deploy a new function → Via editor → name it "account".
// Then in the function's settings, turn OFF "Verify JWT" (this code checks sign-in itself).

import { createClient } from "npm:@supabase/supabase-js@2.49.4";

const EMAIL_DOMAIN = "members.newmercies.app"; // must match app.js
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SB_SECRET_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

// Same derivation as the app: the handle never appears in the login email
async function handleToEmail(handle: string) {
  const norm = handle.trim().toLowerCase().replace(/\s+/g, " ");
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("nm:" + norm));
  const hex = [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  return `u${hex.slice(0, 32)}@${EMAIL_DOMAIN}`;
}

async function caller(req: Request) {
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data.user) return null;
  const { data: m } = await admin.from("members").select("*").eq("id", data.user.id).maybeSingle();
  return m;
}

const WORDS = ["river","stone","cedar","harbor","morning","shield","lamp","anchor","valley","summit",
  "bridge","meadow","beacon","rock","willow","ember","compass","trail","dawn","oak"];
function tempPassword() {
  const r = new Uint32Array(3);
  crypto.getRandomValues(r);
  return `${WORDS[r[0] % WORDS.length]}-${WORDS[r[1] % WORDS.length]}-${10 + (r[2] % 90)}`;
}

const HANDLE_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{1,23}$/;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return json({ error: "Bad request" }, 400); }

  try {
    switch (body.action) {
      case "signup": {
        const code = String(body.code ?? "").trim().toUpperCase();
        const handle = String(body.handle ?? "").trim().replace(/\s+/g, " ");
        const password = String(body.password ?? "");
        const start = String(body.start_date ?? "");

        if (!HANDLE_RE.test(handle)) return json({ error: "Name must be 2–24 letters, numbers, spaces, dots, dashes or underscores." }, 400);
        if (password.length < 8) return json({ error: "Password must be at least 8 characters." }, 400);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(start)) return json({ error: "Please choose a start date." }, 400);

        const { data: invite } = await admin.from("invite_codes").select("*").eq("code", code).maybeSingle();
        if (!invite || invite.uses >= invite.max_uses || new Date(invite.expires_at) < new Date()) {
          return json({ error: "That invite code isn't valid or has expired. Ask your moderator for a new one." }, 400);
        }
        const { data: taken } = await admin.from("members").select("id").ilike("handle", handle.replace(/[\\%_]/g, "\\$&")).maybeSingle();
        if (taken) return json({ error: "That name is already taken in the group. Try another." }, 400);

        const { data: created, error: cErr } = await admin.auth.admin.createUser({
          email: await handleToEmail(handle), password, email_confirm: true,
        });
        if (cErr || !created.user) return json({ error: cErr?.message ?? "Could not create account." }, 400);

        const { error: mErr } = await admin.from("members").insert({
          id: created.user.id, handle, role: invite.role, cluster_id: invite.cluster_id, start_date: start,
        });
        if (mErr) {
          await admin.auth.admin.deleteUser(created.user.id);
          return json({ error: "Could not finish sign-up. Please try again." }, 400);
        }
        await admin.from("invite_codes").update({ uses: invite.uses + 1 }).eq("code", code);
        return json({ ok: true });
      }

      case "reset": {
        const me = await caller(req);
        if (!me || me.role !== "moderator") return json({ error: "Moderators only." }, 403);
        const { data: target } = await admin.from("members").select("*").eq("id", body.member_id).maybeSingle();
        if (!target || target.cluster_id !== me.cluster_id) return json({ error: "Member not found." }, 404);
        const temp = tempPassword();
        const { error } = await admin.auth.admin.updateUserById(target.id, { password: temp });
        if (error) return json({ error: error.message }, 400);
        await admin.from("members").update({ must_change_password: true }).eq("id", target.id);
        return json({ ok: true, temp_password: temp });
      }

      case "remove": {
        const me = await caller(req);
        if (!me || me.role !== "moderator") return json({ error: "Moderators only." }, 403);
        if (body.member_id === me.id) return json({ error: "You can't remove yourself." }, 400);
        const { data: target } = await admin.from("members").select("*").eq("id", body.member_id).maybeSingle();
        if (!target || target.cluster_id !== me.cluster_id) return json({ error: "Member not found." }, 404);
        const { error } = await admin.auth.admin.deleteUser(target.id); // cascades to all their data
        if (error) return json({ error: error.message }, 400);
        return json({ ok: true });
      }

      default:
        return json({ error: "Unknown action" }, 400);
    }
  } catch (e) {
    console.error(e);
    return json({ error: "Something went wrong." }, 500);
  }
});
